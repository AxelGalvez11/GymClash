```markdown
# Design System Document: Tactical Aggression

## 1. Overview & Creative North Star
**Creative North Star: "The Kinetic HUD"**

This design system is not a static interface; it is a high-performance instrument. Moving away from the "flat web" era, we are embracing **Organic Brutalism**—a style that combines raw, unyielding geometry with the fluid, high-velocity energy of a competitive arena. 

The system breaks standard templates through **Intentional Asymmetry**. We do not center-align for comfort; we offset elements to create tension and "forward lean." Components should feel like they were machined from aerospace-grade materials, then overclocked until they glow. By overlapping tactical vector fields with heavy display type, we create a layered, multi-dimensional space that puts the user inside the helmet of a protagonist.

---

## 2. Colors
Our palette is rooted in a high-contrast, "blackout" environment where light is used as a weapon.

*   **Primary Engine (`primary`, `primary_dim`):** The "Blood Red" (#FF0000/`primary_dim`) is our pulse. It is reserved for critical actions, lethal states, and active HUD elements.
*   **Neutral Foundation:** We use `surface` (#0e0e0e) and `surface_container_lowest` (#000000) to create infinite depth, ensuring the red elements "pop" with violent clarity.
*   **The "No-Line" Rule:** Standard 1px borders are strictly prohibited for layout sectioning. Separation is achieved through background shifts (e.g., a `surface_container_high` module sitting on a `surface` backdrop) or sharp, angular geometric "cutouts."
*   **Surface Hierarchy & Nesting:** Treat the UI as a physical stack of tactical plates. Use `surface_container_low` for the base environment and `surface_container_highest` for interactive floating panels.
*   **The "Glass & Gradient" Rule:** To simulate a visor or HUD, use Glassmorphism on overlays. Apply `surface_variant` at 60% opacity with a heavy `backdrop-blur`. 
*   **Signature Textures:** Map the `tertiary_container` as a subtle linear gradient behind key CTAs to simulate a "glowing heat" effect rather than a flat fill.

---

## 3. Typography
Typography is our primary vehicle for "aggression." We utilize a sharp dichotomy between technical data and raw power.

*   **Display & Headlines (Space Grotesk):** These must be implemented with a heavy weight and an intentional **-10° oblique slant** (via CSS transforms) to mimic high-velocity movement. Use `display-lg` for kill-streaks and `headline-md` for tactical headers.
*   **Body & Technical Data (Inter):** The "Engineer’s Font." Used for status reports, item descriptions, and coordinates. This remains unslanted for maximum legibility, acting as the grounded "data" to the "action" of the display type.
*   **Scale Hierarchy:**
    *   **Tactical Labels:** `label-sm` in `on_surface_variant` for small-caps "system" text.
    *   **High-Stakes Alerts:** `headline-lg` in `primary_dim` for game-ending notifications.

---

## 4. Elevation & Depth
In this system, "up" doesn't mean "closer to the light"—it means "more energized."

*   **The Layering Principle:** Avoid shadows where possible. Instead, use "Tonal Steps." A `surface_container_highest` card placed on `surface` creates an aggressive, hard-edged lift.
*   **Ambient Shadows:** If a floating element (like a modal) requires a shadow, it must be a "Glow Shadow." Use the `primary` token at 10% opacity with a 40px blur to simulate the red HUD lighting reflecting off the visor.
*   **The "Ghost Border" Fallback:** For buttons or input fields, use a "Ghost Border" of `outline_variant` at 20% opacity. 
*   **Hard Angles:** All corners are strictly `0px` (Roundness: `none`). To further the "engineered" look, use CSS `clip-path` to create 45-degree "snipped" corners on primary containers.

---

## 5. Components

### Buttons: The "Trigger"
*   **Primary:** Sharp 45-degree clipped corners. Background: `primary_dim`. Border: 2px `primary_fixed` with an outer "neon" glow. Text: `label-md` in `on_primary_fixed` (Black).
*   **Secondary:** Ghost variant. Background: transparent. Border: 1px `outline`. On hover: border flashes `primary` and background fills with 10% `primary`.

### Cards & Modules: The "Plating"
*   **Rule:** Forbid divider lines.
*   **Implementation:** Separate content chunks using a 2px vertical "power bar" of `primary` on the left edge and a shift from `surface_container_low` to `surface_container_high`.

### Input Fields: The "Telemetry"
*   **Style:** Underline only. Use `outline` for inactive states and `primary` for focus. Add a subtle `0.2rem` spacing "glitch" animation on focus where the label slants further.

### Tactical Components (Custom)
*   **Vector Field Overlays:** Subtle SVG patterns of grid lines and coordinates using `outline_variant` at 5% opacity, layered behind character avatars.
*   **Status Bars:** Use `primary_container` for the background and `primary` for the fill. The fill should have a "scanning" gradient animation moving through it.

---

## 6. Do's and Don'ts

### Do:
*   **Use Asymmetry:** Place important "Global" stats on the far left and "Personal" stats on the far right to mimic a wide-screen HUD.
*   **Embrace High Contrast:** Keep the background dark (`#0e0e0e`) and the text bright (`#ffffff`).
*   **Engineer the Details:** Use `label-sm` to add "meaningless" technical fluff (e.g., "SYS_VER_8.0.1") in corners to enhance the tactical feel.

### Don’t:
*   **No Rounded Corners:** Any radius above `0px` is a failure of the system's aggressive intent.
*   **No Centered Layouts:** Avoid the "Standard Web Center Column." Pull elements to the edges of the screen to create a "peripheral vision" HUD effect.
*   **No Soft Colors:** Never use pastels. If it’s not deep black, tactical gray, or blood red, it doesn't belong in the arena.

---

## 7. Character Integration
The **Neutral Gray 3D Figurine** should be treated as a "Ghost in the Machine." 
*   Apply a `surface_variant` tint to the model.
*   Overlay a `primary` vector field (wireframe) at 30% opacity on top of the 3D model to suggest it is a tactical projection rather than a physical person.```